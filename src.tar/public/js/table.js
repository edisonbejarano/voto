$(document).ready(function () {

  $('#table').DataTable({
  "scrollY": "50vh",
  "scrollCollapse": true,
  });

  $('.dataTables_length').addClass('bs-select');


  //showing modal for delete record
  $('#table').on('click','.validar',function(){
    var id_estudiantes_colegios_municipios = $(this).data('id');
    $('#ValidarModal').modal('show');
    $('.id_estudiantes_colegios_municipios_valida').val(id_estudiantes_colegios_municipios);
  });

  $('#table').on('click','.Inscripcion',function(){
    var id_estudiantes_colegios_municipios = $(this).data('id_estudiantes_colegios_municipios');
    var nmbre = $(this).data('nmbre');
    var id_parametros_votacion = $(this).data('id_parametros_votacion');
    $('#InscripcionModal').modal('show');
    $('.id_estudiantes_colegios_municipios_inscripcion').val(id_estudiantes_colegios_municipios);

    $('.nmbre_inscripcion').val(nmbre);
    $('.id_parametros_votacion_inscripcion').val(id_parametros_votacion);
  });

});
