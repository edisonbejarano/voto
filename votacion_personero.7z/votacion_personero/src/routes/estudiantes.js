const express = require('express');
const router  = express.Router();

const pool  = require('../database');
//Lista de Estudiantes Activos Que Ueden Votar --
router.get('/lista',async(reg, res) =>{
var sql_data   = "select	"+
            " RANK()  OVER (PARTITION BY a.id_colegios_municipios "+
            " ORDER by trim(d.prmr_nmbre),trim(d.sgnd_nmbre),trim(d.prmr_aplldo),trim(d.sgnd_aplldo) asc  ) AS row_num, "+
            " CONCAT_WS(' ',d.prmr_nmbre,d.sgnd_nmbre,d.prmr_aplldo,d.sgnd_aplldo) as Nombre_Estudiante, "+
            " CONCAT(j.cdgo,' ',d.nmro_idntfccn) as Numero_Identificacion,c.rzn_scl as rzn_scl,  "+
           	" c.nmro_idntfccn as nmro_idntfccn_clgio,a.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios , "+
           	" a.id_colegios_municipios as id_colegios_municipios,c.id_colegios as id_colegios,  "+
           	" e.id_inscripciones_estudiantes as id_inscripciones_estudiantes,f.id_votaciones as  id_votaciones, "+
            " d.fcha_ncmnto as Fecha_Nacimiento,TIMESTAMPDIFF(YEAR,d.fcha_ncmnto,CURDATE()) AS Edad,  "+
            " g.id_generos as id_generos ,g.dscrpcn as Genero, i.dscrpcn_grds as Grado "+
            " from  	scriptc6_blockchain_votacion.tb_estudiantes_colegios_municipios as a "+
            " inner join scriptc6_blockchain_votacion.tb_colegios_municipios as b "+
           	"   on a.id_colegios_municipios = b.id_colegios_municipios  "+
            " inner join scriptc6_blockchain_votacion.tb_colegios as c  "+
           	"   on c.id_colegios = b.id_colegios  "+
            " INNER JOIN scriptc6_blockchain_votacion.tb_estudiantes as d "+
           	"   on d.id_estudiantes = a.id_estudiantes  "+
            " left outer join scriptc6_blockchain_votacion.tb_inscripciones_estudiantes as e  "+
           	"   on e.id_estudiantes_colegios_municipios = a.id_estudiantes_colegios_municipios  "+
            " left outer join scriptc6_blockchain_votacion.tb_votaciones as f "+
           	"   on f.id_inscripciones_estudiantes = e.id_inscripciones_estudiantes  "+
            " inner join 	scriptc6_blockchain_votacion.tb_generos as g "+
            "   on g.id_generos = d.id_genero "+
            " inner join  scriptc6_blockchain_votacion.tb_estudiantes_informacion as h"+
            "   on  a.id_estudiantes_colegios_municipios = h.id_estudiantes_colegios_municipios "+
            " inner JOIN scriptc6_blockchain_votacion.tb_grados as i "+
            "   on i.id_grados = h.id_grados "+
            " inner join  scriptc6_blockchain_votacion.tb_tipos_identificaciones j "+
            "   on j.id_tipos_identificaciones = d.id_tpo_idntfccn "+
            " where c.id_estdo_clgio = '01' "+
            " 	and d.id_estdo_estdnte = '01' "+
            "   and h.id_colegios_municipios = 7 "+
            "   and h.estdo is TRUE "+
            "   and now() BETWEEN h.ano_lctvo_incl and h.ano_lctvo_fnl "+
            " order by trim(d.prmr_nmbre),trim(d.sgnd_nmbre),trim(d.prmr_aplldo),trim(d.sgnd_aplldo) asc";

  const Data_Estudiantes = await pool.query(sql_data);
  res.render('estudiantes/lista',{ Data_Estudiantes });
});

router.get('/validar/:id_estudiantes_colegios_municipios', async(req, res)=>{
  var id_estudiantes_colegios_municipios  = req.params.id_estudiantes_colegios_municipios;
  var id_login_sccn = '1';
  await pool.query("INSERT INTO tb_inscripciones_estudiantes "+
                   " (id_estudiantes_colegios_municipios,id_login_crcn,id_login_mdfccn) VALUES(? ,?,?)",
                  [id_estudiantes_colegios_municipios,id_login_sccn,id_login_sccn],(err , res) =>{
        pool.end();
  });
  //contuacion con hyperlead
 res.redirect('/estudiantes/lista');
 
});

module.exports = router;
