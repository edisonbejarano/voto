module.exports = {

  database:{
     user: 'admin',//'scriptc6_blockachain',
     database: 'scriptc6_blockchain_votacion',
     host: 'vote.ckqhltmqznnb.us-east-1.rds.amazonaws.com',//'sistemaseinformacion.com.co',
     password: 'S0p0rt3*',
     port: 3306,
     sessionVariables: { wait_timeout: 31536000 }, acquireTimeout: 5000, connectionLimit: 8,
  }

};
