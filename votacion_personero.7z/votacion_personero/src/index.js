require('./config/config');
const express = require('express');
const exphbs  = require('express-handlebars');
const handlebars  = require('handlebars');
const path    = require('path');
const morgan  = require('morgan');
const SHA256 = require("crypto-js/sha256");
//initialization
const app = express();

//settings
app.set('port',process.env.PORT || 3000);
app.set('views',path.join(__dirname,'views'));
//app.set('view engine', 'handlebars');
//app.engine('handlebars', exphbs());
app.engine('.hbs', exphbs({
  defaultdLayout: 'main',
  layoutsDir: path.join(app.get('views'), 'layouts'),
  partialsDir: path.join(app.get('views'), 'partials'),
  extname: '.hbs',
  helpers: require('./lib/handlebars')
}));
app.set('view engine', '.hbs');

//Middlewares
const bodyParser = require('body-parser');
app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use(morgan('dev'));

//Global Variables
app.use((req, res, next) =>{
    next();
});
//Routers
app.use(require('./routes'));
app.use('/votacion'    , require('./routes/Votacion'));
app.use('/candidatos'  , require('./routes/Candidatos'));
app.use('/estudiantes' , require('./routes/estudiantes'));

//public
app.use(express.static(path.join(__dirname, 'public')));
//star the server}

app.listen(process.env.PORT, () =>{
  console.log('Servidor Corriendo Puerto',process.env.PORT)
});
