<?php
$str_button      = 'Scriptcase7_SilverBlue';
$str_chart_theme = '';
$str_google_fonts = "";
$str_tab_space = '2px';
$index_class_pos = '';
$index_class_neg = '';
$index_class_neu = '';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
?>