<?php 
  include_once('../Candidatos/index.php'); 
?> 
