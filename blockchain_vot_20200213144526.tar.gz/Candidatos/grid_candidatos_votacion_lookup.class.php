<?php
class grid_candidatos_votacion_lookup
{
}
?>
