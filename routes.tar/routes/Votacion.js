const express    = require('express');
const router     = express.Router();
const pool       = require('../database');

router.get('/',async(require, response) =>{
  let sql_documento = " select id_tipos_identificaciones,dscrpcn as dscrpcn_dcmnto "+
                      "   from scriptc6_blockchain_votacion.tb_tipos_identificaciones where estdo is TRUE "+
                      " union "+
                      " select NULL as  id_tipos_identificaciones , 'SELECCIONE ...' as dscrpcn "+
                      " order by id_tipos_identificaciones" ;
  const Data_documento = await pool.query(sql_documento);

  let sql_parametros = " select id_parametros_votacion, CONCAT(dscrpcn,' - ',YEAR(fcha_vtcn_incio)) as dscrpcn_prmtrs"+
                      " from scriptc6_blockchain_votacion.tb_parametros_votaciones "+
                      " where estdo is TRUE   and now() BETWEEN fcha_vtcn_incio and fcha_vtcn_fnlza ";
  const Data_parametros = await pool.query(sql_parametros);
  response.render('Votacion/inicio',{ Data_documento , Data_parametros });
});

router.post('/lista_candidatos',async(req, res) =>{
  var  lb_votacion
  var  id_tpo_idntfccn        = req.body.id_tpo_idntfccn
  var  nmro_idntfccn          =  req.body.nmro_idntfccn
  var  id_parametros_votacion = req.body.id_parametros_votacion
  //verifico que el alumno exista
  var check_sql = "select a.id_estudiantes as id_estudiantes , "+
          " b.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios, "+
          " b.id_colegios_municipios as id_colegios_municipios, "+
          " CONCAT_WS(' ',a.prmr_nmbre,a.sgnd_nmbre,a.prmr_aplldo,a.sgnd_aplldo) as nmbre "+
          " from scriptc6_blockchain_votacion.tb_estudiantes as a "+
          "	inner join scriptc6_blockchain_votacion.tb_estudiantes_colegios_municipios as b "+
          "	on a.id_estudiantes = b.id_estudiantes "+
          "	inner join scriptc6_blockchain_votacion.tb_tipos_identificaciones as c "+
          "	on c.id_tipos_identificaciones = a.id_tpo_idntfccn "+
          " where a.nmro_idntfccn = '"+nmro_idntfccn+"'"+
          "	and c.id_tipos_identificaciones = "+id_tpo_idntfccn+
          "	and b.estdo is true";
    const   results = await  pool.query(check_sql)
    if(results[0] === 'undefined'){
      console.log('ALumnoo No Registra Veririf los datos');
      res.redirect('/Votacion');
    }else{
       console.log('verifico validacion');
       let ln_id_estudiantes = results[0].id_estudiantes
       let ln_id_estudiantes_colegios_municipios = results[0].id_estudiantes_colegios_municipios
       let ln_id_colegios_municipios = results[0].id_colegios_municipios
       let lc_nmbre = results[0].nmbre
       let sql_inscripcion = "SELECT id_inscripciones_estudiantes "+
                             "	from tb_inscripciones_estudiantes "+
                             "	where id_estudiantes_colegios_municipios ="+ln_id_estudiantes_colegios_municipios;
      const rs_inscripcion = await  pool.query(sql_inscripcion)
      if(rs_inscripcion[0] === 'undefined'){
        console.log('Alumno no esta Validado');
        res.redirect('/Votacion');
      }else{
        console.log('verifico que no haya votado')
        let ln_id_inscripciones_estudiantes = rs_inscripcion[0].id_inscripciones_estudiantes;

        let sql_votacion = "select a.id_votaciones, "+
            " CONCAT_WS(' ',trim(d.prmr_nmbre),trim(d.sgnd_nmbre),trim(d.prmr_aplldo),trim(d.sgnd_aplldo)) as nmbre_vtnte, "+
            " d.nmro_idntfccn as nmro_idntfccn,e.cdgo as cdgo_idntfccn,a.fcha_rgstro as fcha_rgstro,concat(f.dscrpcn,' ',year(f.fcha_vtcn_incio)) as prdd "+
            " from tb_votaciones as a "+
            " inner join tb_inscripciones_estudiantes as b "+
            "     on a.id_inscripciones_estudiantes = b.id_inscripciones_estudiantes "+
            " inner join tb_estudiantes_colegios_municipios as c "+
            "     on c.id_estudiantes_colegios_municipios = b.id_estudiantes_colegios_municipios "+
            " inner join tb_estudiantes as d "+
            "      on d.id_estudiantes = c.id_estudiantes "+
            " inner join tb_tipos_identificaciones as e "+
            "       on e.id_tipos_identificaciones = d.id_tpo_idntfccn "+
            " inner join tb_parametros_votaciones as f "+
            "      on f.id_parametros_votacion = a.id_parametros_votacion "+
            " where a.id_inscripciones_estudiantes = "+ln_id_inscripciones_estudiantes+
            " and a.id_parametros_votacion = "+id_parametros_votacion+
            " and f.estdo is true";
        const  rs_votacion = await  pool.query(sql_votacion)
        if(rs_votacion[0] === 'undefined'){
          let check_sql = " SELECT DISTINCT CONCAT_ws(' ',c.prmr_nmbre,c.sgnd_nmbre,c.prmr_aplldo,c.sgnd_aplldo) as nmbre, "+
                          "   d.foto as foto ,a.id_inscripciones_candidatos, "+
                          "   b.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios , "+
                          "   a.id_parametros_votacion as id_parametros_votacion "+
                          " from scriptc6_blockchain_votacion.tb_inscripciones_candidatos as a "+
                          " inner join scriptc6_blockchain_votacion.tb_estudiantes_colegios_municipios as b "+
                          "   on a.id_estudiantes_colegios_municipios = b.id_estudiantes_colegios_municipios "+
                          " inner join scriptc6_blockchain_votacion.tb_estudiantes as c "+
                          "   on c.id_estudiantes = b.id_estudiantes "+
                          " left outer join scriptc6_blockchain_votacion.tb_fotos as d "+
                          "   on d.id_estudiantes = c.id_estudiantes "+
                          " where a.id_parametros_votacion   ="+id_parametros_votacion+" order by c.prmr_nmbre,c.sgnd_nmbre,c.prmr_aplldo,c.sgnd_aplldo";
          const lista_candidatos =    pool.query(check_sql)
          res.render('Votacion/lista_candidatos',{ lista_candidatos });
        }else{
          console.log('ya voto');
          let lc_nmbre    = rs_votacion[0].nmbre_vtnte
          let lc_idntfccn = rs_votacion[0].cdgo_idntfccn+' '+rs_votacion[0].nmro_idntfccn
          let ld_fcha_vto = rs_votacion[0].fcha_rgstro
          let lc_prdd     = rs_votacion[0].prdd
          res.redirect('/Votacion');
        }
      }
   }
});

module.exports = router;
