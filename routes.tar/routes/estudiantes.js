const express = require('express');
const router  = express.Router();
const BlockChain = require('../config/blockchain')
const pool  = require('../database');
//Lista de Estudiantes Activos Que Ueden Votar --
router.get('/lista',async(reg, res) =>{
var sql_data   = "select	"+
            " RANK()  OVER (PARTITION BY a.id_colegios_municipios "+
            " ORDER by trim(d.prmr_nmbre),trim(d.sgnd_nmbre),trim(d.prmr_aplldo),trim(d.sgnd_aplldo) asc  ) AS row_num, "+
            " CONCAT_WS(' ',d.prmr_nmbre,d.sgnd_nmbre,d.prmr_aplldo,d.sgnd_aplldo) as Nombre_Estudiante, "+
            " CONCAT(j.cdgo,' ',d.nmro_idntfccn) as Numero_Identificacion,c.rzn_scl as rzn_scl,  "+
           	" c.nmro_idntfccn as nmro_idntfccn_clgio,a.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios , "+
           	" a.id_colegios_municipios as id_colegios_municipios,c.id_colegios as id_colegios,  "+
           	" e.id_inscripciones_estudiantes as id_inscripciones_estudiantes,f.id_votaciones as  id_votaciones, "+
            " d.fcha_ncmnto as Fecha_Nacimiento,TIMESTAMPDIFF(YEAR,d.fcha_ncmnto,CURDATE()) AS Edad,  "+
            " g.id_generos as id_generos ,g.dscrpcn as Genero, i.dscrpcn_grds as Grado "+
            " from  	scriptc6_blockchain_votacion.tb_estudiantes_colegios_municipios as a "+
            " inner join scriptc6_blockchain_votacion.tb_colegios_municipios as b "+
           	"   on a.id_colegios_municipios = b.id_colegios_municipios  "+
            " inner join scriptc6_blockchain_votacion.tb_colegios as c  "+
           	"   on c.id_colegios = b.id_colegios  "+
            " INNER JOIN scriptc6_blockchain_votacion.tb_estudiantes as d "+
           	"   on d.id_estudiantes = a.id_estudiantes  "+
            " left outer join scriptc6_blockchain_votacion.tb_inscripciones_estudiantes as e  "+
           	"   on e.id_estudiantes_colegios_municipios = a.id_estudiantes_colegios_municipios  "+
            " left outer join scriptc6_blockchain_votacion.tb_votaciones as f "+
           	"   on f.id_inscripciones_estudiantes = e.id_inscripciones_estudiantes  "+
            " inner join 	scriptc6_blockchain_votacion.tb_generos as g "+
            "   on g.id_generos = d.id_genero "+
            " inner join  scriptc6_blockchain_votacion.tb_estudiantes_informacion as h"+
            "   on  a.id_estudiantes_colegios_municipios = h.id_estudiantes_colegios_municipios "+
            " inner JOIN scriptc6_blockchain_votacion.tb_grados as i "+
            "   on i.id_grados = h.id_grados "+
            " inner join  scriptc6_blockchain_votacion.tb_tipos_identificaciones j "+
            "   on j.id_tipos_identificaciones = d.id_tpo_idntfccn "+
            " where c.id_estdo_clgio = '01' "+
            " 	and d.id_estdo_estdnte = '01' "+
            "   and h.id_colegios_municipios = 7 "+
            "   and h.estdo is TRUE "+
            "   and now() BETWEEN h.ano_lctvo_incl and h.ano_lctvo_fnl "+
            " order by trim(d.prmr_nmbre),trim(d.sgnd_nmbre),trim(d.prmr_aplldo),trim(d.sgnd_aplldo) asc";

  const Data_Estudiantes = await pool.query(sql_data);
  res.render('estudiantes/lista',{ Data_Estudiantes });
});

router.post('/validar', async(req, res)=>{
  let id_estudiantes_colegios_municipios = req.body.id_estudiantes_colegios_municipios;
  let id_login_sccn = '1';
  let hash_estdnte = "jdlkaqmñd21op2p1opo12e9210"; //BlockChain.hash_public();
  let dts_inscrpcn   = " select DISTINCT a.id_inscripciones_estudiantes as id_inscripciones_estudiantes ,"+
                   " concat_ws(' ',c.prmr_nmbre,c.sgnd_nmbre,c.prmr_aplldo,c.sgnd_aplldo) as nmbre "+
                   "   from tb_inscripciones_estudiantes as a "+
                   "  inner join tb_estudiantes_colegios_municipios as b "+
                   "   on b.id_estudiantes_colegios_municipios = a.id_estudiantes_colegios_municipios "+
                   "  inner join tb_estudiantes as c "+
                   "   on c.id_estudiantes = b.id_estudiantes "+
                   "  where a.id_estudiantes_colegios_municipios = "+id_estudiantes_colegios_municipios+
                   "  and trim(a.hash_estdnte) = trim('"+hash_estdnte+"')";
  try {
    await pool.query("INSERT INTO tb_inscripciones_estudiantes "+
                     " (id_estudiantes_colegios_municipios,hash_estdnte,id_login_crcn,id_login_mdfccn) VALUES(?,?,?,?)",
                    [id_estudiantes_colegios_municipios,hash_estdnte,id_login_sccn,id_login_sccn])
                    //busco id de la inscripcion y el nombre para enviarlos a
                    const dts_inscrpcn_estdnte = await pool.query(dts_inscrpcn);
                    let id_inscripciones_estudiantes = dts_inscrpcn_estdnte[0].id_inscripciones_estudiantes;
                    let nmbre_estdnte = dts_inscrpcn_estdnte[0].nmbre;
                    BlockChain.datos_estudiantes(id_estudiantes_colegios_municipios,hash_estdnte,nmbre_estdnte,id_inscripciones_estudiantes);
  }catch(err){
    console.error(err)
     setImmediate(() => { throw err })
  }
  req.flash('success',"Estudiante Validado. Puede Votar");
  res.redirect('/estudiantes/lista');
});

module.exports = router;
