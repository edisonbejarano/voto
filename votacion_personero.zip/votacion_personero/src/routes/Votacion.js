const express = require('express');
const router  = express.Router();
const pool    = require('../database');

router.get('/inicio',async(reg, res) =>{
  let sql_documento = " select id_tipos_identificaciones,dscrpcn as dscrpcn_dcmnto "+
                      "   from scriptc6_blockchain_votacion.tb_tipos_identificaciones where estdo is TRUE "+
                      " union "+
                      " select 0 as  id_tipos_identificaciones , 'SELECCIONE ...' as dscrpcn "+
                      " order by id_tipos_identificaciones" ;
  const Data_documento = await pool.query(sql_documento);
  let sql_parametros = " select id_parametros_votacion, CONCAT(dscrpcn,' - ',YEAR(fcha_vtcn_incio)) as dscrpcn_prmtrs"+
                      " from scriptc6_blockchain_votacion.tb_parametros_votaciones "+
                      " where estdo is TRUE   and now() BETWEEN fcha_vtcn_incio and fcha_vtcn_fnlza ";
  const Data_parametros = await pool.query(sql_parametros);
  res.render('Votacion/inicio',{ Data_documento , Data_parametros });
});

router.post('/inicio',async(reg,res)=>{
  var tipos_identificaciones = reg.body.tipos_identificaciones;
  var txt_usuario = reg.body.txt_usuario;
  //verifico que el estudiante exista
  let check_sql = "select a.id_estudiantes as id_estudiantes , "+
        " b.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios, "+
        " b.id_colegios_municipios as id_colegios_municipios, "+
				" CONCAT_WS(' ',a.prmr_nmbre,a.sgnd_nmbre,a.prmr_aplldo,a.sgnd_aplldo) as nmbre "+
				" from scriptc6_blockchain_votacion.tb_estudiantes as a "+
				"	inner join scriptc6_blockchain_votacion.tb_estudiantes_colegios_municipios as b "+
				"	on a.id_estudiantes = b.id_estudiantes "+
				"	inner join scriptc6_blockchain_votacion.tb_tipos_identificaciones as c "+
				"	on c.id_tipos_identificaciones = a.id_tpo_idntfccn "+
				" where a.nmro_idntfccn = '"+txt_usuario+"'"+
				"	and c.id_tipos_identificaciones = "+tipos_identificaciones+
				"	and b.estdo is true";
  const rs = await pool.query(check_sql);
  console.log(rs[0]);
  res.send('recivido');

});

router.get('/lista_candidatos/:id_parametros_votacion',async(request, response ) => {
  console.log(request.params);
  var id_parametros_votacion = 1;
  let check_sql = " SELECT DISTINCT CONCAT_ws(' ',c.prmr_nmbre,c.sgnd_nmbre,c.prmr_aplldo,c.sgnd_aplldo) as nmbre, "+
                  "   d.foto as foto ,a.id_inscripciones_candidatos, "+
                  "   b.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios , "+
                  "   a.id_parametros_votacion as id_parametros_votacion "+
                  " from scriptc6_blockchain_votacion.tb_inscripciones_candidatos as a "+
                  " inner join scriptc6_blockchain_votacion.tb_estudiantes_colegios_municipios as b "+
                  "   on a.id_estudiantes_colegios_municipios = b.id_estudiantes_colegios_municipios "+
                  " inner join scriptc6_blockchain_votacion.tb_estudiantes as c "+
                  "   on c.id_estudiantes = b.id_estudiantes "+
                  " left outer join scriptc6_blockchain_votacion.tb_fotos as d "+
                  "   on d.id_estudiantes = c.id_estudiantes "+
                  " where a.id_parametros_votacion   ="+id_parametros_votacion+" order by c.prmr_nmbre,c.sgnd_nmbre,c.prmr_aplldo,c.sgnd_aplldo";
 const lista_candidatos = await pool.query(check_sql);

 const data1 = { lista_candidatos };
 //console.log(JSON.stringify(lista_candidatos[0]));
 //console.log(object.value(lista_candidatos));


// const row = response.json(lista_candidatos);
  //console.log('data1'+data1);
 //  console.log(lista_candidatos[0]);
  response.render('Votacion/lista_candidatos',{ lista_candidatos });
});

module.exports = router;
