const express = require('express');
const router  = express.Router();

const pool  = require('../database');
router.get('/inicial',async(reg, res) =>{
//Lista de Estudiantes Activos Que Ueden Votar --
//paramatros de votacion para registro de candidatos
let sql_parametros = "SELECT  a.id_parametros_votacion as id_parametros_votacion ,CONCAT(a.dscrpcn,' - ',YEAR(a.fcha_vtcn_incio)) as dscrpcn"+
                  " FROM scriptc6_blockchain_votacion.tb_parametros_votaciones as a where a.estdo is true";
const Data_parametros = await pool.query(sql_parametros);
res.render('Candidatos/inicial',{ Data_parametros });
});


router.get('/lista', async (reg, res) =>{
  //console.log(req.params.id_parametros_votacion);
let ln_id_parametros_votacion =  1;//Data_parametros[0]['id_parametros_votacion'];
//datos de los alumnos que pueden ser candidatos se valida por paramatrizacion de votacion
//solo debe mostrar los alumnos de los grados que puedan votar y valida que el parametro de votacion
//esta habilitado
let sql_data ='';
if (ln_id_parametros_votacion > 0){
  sql_data   = "select "+
     " RANK()  OVER (PARTITION BY id_colegios_municipios  "+
     " ORDER by  prmr_nmbre,sgnd_nmbre,prmr_aplldo,sgnd_aplldo  asc  ) AS row_num, "+
     " prmr_nmbre,sgnd_nmbre,prmr_aplldo,sgnd_aplldo, "+
     " dscrpcn_grds,cdgo,nmro_idntfccn,edad, "+
     " id_estudiantes_colegios_municipios,id_colegios_municipios, "+
     " id_inscripciones_candidatos,dscrpcn_estdo,id_parametros_votacion, "+
     " CONCAT_WS(' ', prmr_nmbre,sgnd_nmbre,prmr_aplldo,sgnd_aplldo) as nmbre, "+
     " CONCAT_WS(' ',cdgo,nmro_idntfccn) as nmro_idntfccn "+
  " from "+
    " ((select e.prmr_nmbre,e.sgnd_nmbre,e.prmr_aplldo,e.sgnd_aplldo, "+
    " d.dscrpcn_grds  as dscrpcn_grds,f.cdgo as cdgo,e.nmro_idntfccn as nmro_idntfccn, "+
    " f.dscrpcn as dscrpcn_idntfccn,TIMESTAMPDIFF(YEAR,e.fcha_ncmnto,CURDATE()) AS edad, "+
    " c.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios, "+
    " c.id_colegios_municipios as id_colegios_municipios, c.id_grados, "+
    " f.id_tipos_identificaciones as id_tipos_identificaciones,c.ano_lctvo_incl, c.ano_lctvo_fnl , "+
    " h.id_inscripciones_candidatos as id_inscripciones_candidatos,i.id_estado as id_estado , "+
    " i.dscrpcn_estdo as dscrpcn_estdo, h.id_parametros_votacion as id_parametros_votacion "+
       " FROM  tb_estudiantes_colegios_municipios as a  "+
       " inner join scriptc6_blockchain_votacion.tb_colegios_municipios as b  "+
       " on a.id_colegios_municipios = b.id_colegios_municipios  "+
       " inner join scriptc6_blockchain_votacion.tb_estudiantes_informacion as c  "+
       " on c.id_estudiantes_colegios_municipios = a.id_estudiantes_colegios_municipios "+
       " and c.id_colegios_municipios = b.id_colegios_municipios  "+
       " inner join scriptc6_blockchain_votacion.tb_grados as d  "+
       " on d.id_grados = c.id_grados  "+
       " inner join scriptc6_blockchain_votacion.tb_estudiantes as e  "+
       " on e.id_estudiantes = a.id_estudiantes  "+
       " INNER JOIN  scriptc6_blockchain_votacion.tb_tipos_identificaciones as f  "+
       " on f.id_tipos_identificaciones = e.id_tpo_idntfccn   "+
       " INNER JOIN scriptc6_blockchain_votacion.tb_estados as g  "+
       " on g.id_estado = e.id_estdo_estdnte  "+
       " left outer join scriptc6_blockchain_votacion.tb_inscripciones_candidatos as h  "+
       " on h.id_estudiantes_colegios_municipios = a.id_estudiantes_colegios_municipios  "+
       " left outer JOIN scriptc6_blockchain_votacion.tb_estados as i  "+
       " on i.id_estado = h.id_estdo_cnddto  "+
       " inner join scriptc6_blockchain_votacion.tb_parametros_votaciones as j "+
       " on j.id_parametros_votacion = h.id_parametros_votacion "+
       " where b.id_colegios_municipios = 7  "+
       " 	and d.aplca_cnddto is true  "+
       " 	and date(now()) BETWEEN c.ano_lctvo_incl and c.ano_lctvo_fnl   "+
       " 	and  e.id_estdo_estdnte = '01'  "+
      "   and  h.id_parametros_votacion = "+ln_id_parametros_votacion+")"+
    " UNION  "+
    " (select e.prmr_nmbre,e.sgnd_nmbre,e.prmr_aplldo,e.sgnd_aplldo, "+
    	 " d.dscrpcn_grds  as dscrpcn_grds,f.cdgo as cdgo,e.nmro_idntfccn as nmro_idntfccn, "+
       " f.dscrpcn as dscrpcn_idntfccn,TIMESTAMPDIFF(YEAR,e.fcha_ncmnto,CURDATE()) AS edad, "+
       " c.id_estudiantes_colegios_municipios as id_estudiantes_colegios_municipios, "+
    	 " c.id_colegios_municipios as id_colegios_municipios, c.id_grados, "+
    	 " f.id_tipos_identificaciones as id_tipos_identificaciones,c.ano_lctvo_incl, c.ano_lctvo_fnl , "+
    	 " h.id_inscripciones_candidatos as id_inscripciones_candidatos,i.id_estado as id_estado , "+
       " i.dscrpcn_estdo as dscrpcn_estdo, h.id_parametros_votacion as id_parametros_votacion "+
       " FROM  tb_estudiantes_colegios_municipios as a  "+
        " inner join scriptc6_blockchain_votacion.tb_colegios_municipios as b  "+
        " on a.id_colegios_municipios = b.id_colegios_municipios  "+
        " inner join scriptc6_blockchain_votacion.tb_estudiantes_informacion as c  "+
        " on c.id_estudiantes_colegios_municipios = a.id_estudiantes_colegios_municipios   "+
        " and c.id_colegios_municipios = b.id_colegios_municipios  "+
        " inner join scriptc6_blockchain_votacion.tb_grados as d  "+
        " on d.id_grados = c.id_grados  "+
        " inner join scriptc6_blockchain_votacion.tb_estudiantes as e  "+
        " 	on e.id_estudiantes = a.id_estudiantes  "+
        " INNER JOIN  scriptc6_blockchain_votacion.tb_tipos_identificaciones as f  "+
        " 	on f.id_tipos_identificaciones = e.id_tpo_idntfccn   "+
        " INNER JOIN scriptc6_blockchain_votacion.tb_estados as g  "+
        " 	on g.id_estado = e.id_estdo_estdnte  "+
        " left outer join scriptc6_blockchain_votacion.tb_inscripciones_candidatos as h  "+
        " on h.id_estudiantes_colegios_municipios = a.id_estudiantes_colegios_municipios  "+
        " left outer JOIN scriptc6_blockchain_votacion.tb_estados as i  "+
        " on i.id_estado = h.id_estdo_cnddto  "+
        " left outer join scriptc6_blockchain_votacion.tb_parametros_votaciones as j "+
        " on j.id_parametros_votacion = h.id_parametros_votacion "+
        " where b.id_colegios_municipios = 7  "+
        " and d.aplca_cnddto is true  "+
        " and date(now()) BETWEEN c.ano_lctvo_incl and c.ano_lctvo_fnl   "+
        " and  e.id_estdo_estdnte = '01'  "+
        " and  (h.id_parametros_votacion not in(select id_parametros_votacion  "+
        "                                     from scriptc6_blockchain_votacion.tb_parametros_votaciones "+
        "                                     where id_parametros_votacion = "+ln_id_parametros_votacion+" ) "+
        "                                       or h.id_parametros_votacion is null) )) as tbl "+
  " order by prmr_nmbre,sgnd_nmbre,prmr_aplldo,sgnd_aplldo asc";
  Data_Candidatos = await pool.query(sql_data);
  res.render('Candidatos/lista',{ Data_Candidatos });
}else{
  const Data_Candidatos = '';
  res.render('Candidatos/lista',{ Data_Candidatos })
}

});

router.get('/inscripcion/:id_estudiantes_colegios_municipios', async(req, res)=>{
  var { id_estudiantes_colegios_municipios }  = req.params;
  var id_login_sccn = '1';
  let slq_data = "SELECT id_estado from scriptc6_blockchain_votacion.tb_estados  where estdo is true and cdgo_estdo ='01'";
  const Data_estado = await pool.query(slq_data);
  res.render('Candidatos/inscripcion',{ Data_estado });

console.log('resutado'+{ Data_estado });
var id_estado =  Data_estado[0][id_estado];
  console.log('resutado'+Data_estado[0]);
  console.log('id_estado '+id_estado);
/*  await pool.query("INSERT INTO scriptc6_blockchain_votacion.tb_inscripciones_candidatos "+
                   " (id_estudiantes_colegios_municipios,id_parametros_votacion,id_estdo_cnddto,id_login_crcn,id_login_mdfccn) VALUES(?,?,?,?,?)",
                  [id_estudiantes_colegios_municipios,id_parametros_votacion,id_estado,id_login_sccn,id_login_sccn],(err , res) =>{
        pool.end();
  });*/
  //contuacion con hyperlead
 res.redirect('/Candidatos/lista');
});
module.exports = router;
