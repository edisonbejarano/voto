const express = require('express');
const router  = express.Router();

router.get('/', (req, res) => {
  console.log("Got a GET request for the homepage");
  res.send('Prueba');
})

module.exports = router;
