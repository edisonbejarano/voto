process.env.PORT = process.env.PORT || 3000;
process.env.DB_USER = process.env.DB_USER || 'admin';//'scriptc6_blockachain';
process.env.DB_HOST = process.env.DB_HOST || 'vote.ckqhltmqznnb.us-east-1.rds.amazonaws.com';
