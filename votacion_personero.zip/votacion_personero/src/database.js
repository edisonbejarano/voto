 const mariadb = require("mariadb");
 const { database }  = require('./keys');

 const pool = mariadb.createPool(database);

 pool.getConnection()
    .then(connection => {
      console.log("connected ! connection id is " + connection.threadId);
      connection.release(); //release to pool
    })
    .catch(err => {
      if(err.code == 'PROTOCOL_CONNECTION_LOST'){
          console.error('Error : '+err.message);
      }
      if(err.code == 'ER_CON_COUNT_ERROR'){
          console.error('Error : '+err.message);
      }
      if(err.code == 'ECONNREFUSED'){
          console.error('Error : '+err.message);
      }
    });

 module.exports = pool;
